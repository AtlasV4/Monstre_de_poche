package com.esiea.pootd2.commands;

public class ErrorCommand extends Command {

    private String errorMessage;

    public ErrorCommand(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String doCommand() {
        return "\u001B[31m[ERROR] " + errorMessage + "\u001B[0m";
    }
}

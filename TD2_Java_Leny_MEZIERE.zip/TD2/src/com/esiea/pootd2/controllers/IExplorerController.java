package com.esiea.pootd2.controllers;

import com.esiea.pootd2.models.FolderInode;

public interface IExplorerController {

    public String executeCommand(String commandStr);

    public FolderInode getCurrentFolder();
}

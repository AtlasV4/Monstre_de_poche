package com.esiea.pootd2.controllers;

import com.esiea.pootd2.commands.*;
import com.esiea.pootd2.commands.parsers.UnixLikeCommandParser;
import com.esiea.pootd2.models.FolderInode;

public class ExplorerController implements IExplorerController{

    private FolderInode currentFolder;
    private UnixLikeCommandParser parser;

    public ExplorerController() {
        this.currentFolder = new FolderInode("/");
        this.parser = new UnixLikeCommandParser();
    }
    @Override
    public String executeCommand(String commandStr) {
        Command command = parser.parse(commandStr);
        return doCommand(command);
    }

    private String doCommand(Command cmd) {

        if (cmd instanceof ListCommand listCmd) {
            return listCmd.doCommand(currentFolder);
        }

        if (cmd instanceof TouchCommand touchCmd) {
            int result = touchCmd.doCommand((currentFolder));
            if(result == 0) {
                return new ErrorCommand("File already exist").doCommand();
            }
            return "";
        }

        if (cmd instanceof MakeDirectoyCommand mkdirCmd) {
            int result = mkdirCmd.doCommand((currentFolder));
            if(result == 0) {
                return new ErrorCommand("Folder already exist").doCommand();
            }
            return "";
        }

        if (cmd instanceof ChangeDirectoryCommand cdCmd) {
            FolderInode newFolder = cdCmd.doCommand(currentFolder);

            if (newFolder == null) {
                return new ErrorCommand("Folder not found").doCommand();
            }

            currentFolder = newFolder;
            return "";
        }

        if (cmd instanceof ErrorCommand errCmd) {
            return errCmd.doCommand();
        }

        return "Unknow error";
    }

    @Override
    public FolderInode getCurrentFolder() {
        return this.currentFolder;
    }
}

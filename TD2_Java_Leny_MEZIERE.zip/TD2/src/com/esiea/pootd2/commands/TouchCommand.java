package com.esiea.pootd2.commands;

import com.esiea.pootd2.models.FileInode;
import com.esiea.pootd2.models.FolderInode;
import com.esiea.pootd2.models.Inode;

import java.util.Objects;

public class TouchCommand extends Command {

    private String name;

    public TouchCommand(String name) {
        this.name = name;
    }

    public int doCommand(FolderInode folderInode) {
        for(Inode inode : folderInode.getChildren()) {
            if(inode instanceof FileInode && Objects.equals(inode.getName(), name)) {
                return 0;
            }
        }
        folderInode.addInode(new FileInode(name));
        return 1;
    }
}

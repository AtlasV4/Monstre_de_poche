package com.esiea.pootd2.commands;

import com.esiea.pootd2.models.FolderInode;
import com.esiea.pootd2.models.Inode;

import java.util.Objects;

public class MakeDirectoyCommand extends Command {

    private String name;

    public MakeDirectoyCommand(String name) {
        this.name = name;
    }

    public int doCommand(FolderInode folderInode) {
        for(Inode inode : folderInode.getChildren()) {
            if(inode instanceof FolderInode && Objects.equals(inode.getName(), name)) {
                return 0;
            }
        }
        folderInode.addInode(new FolderInode(name));
        return 1;
    }
}

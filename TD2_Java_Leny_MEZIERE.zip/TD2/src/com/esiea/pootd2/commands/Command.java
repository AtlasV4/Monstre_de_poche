package com.esiea.pootd2.commands;

public abstract class Command {

}

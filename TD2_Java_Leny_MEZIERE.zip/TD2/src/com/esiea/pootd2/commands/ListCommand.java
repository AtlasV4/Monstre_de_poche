package com.esiea.pootd2.commands;

import com.esiea.pootd2.models.FileInode;
import com.esiea.pootd2.models.FolderInode;
import com.esiea.pootd2.models.Inode;

public class ListCommand extends Command {

    public String doCommand(FolderInode folder) {
        StringBuilder builder = new StringBuilder();

        final String RESET = "\u001B[0m";
        final String BLUE = "\u001B[34m";
        final String GREEN = "\u001B[32m";

        boolean last = false;

        for (Inode child : folder.getChildren()) {

            if(folder.getChildren().indexOf(child) == folder.getChildren().size()-1) {
                last = true;
            }

            if (child instanceof FolderInode) {
                builder.append(BLUE);
            } else if (child instanceof FileInode) {
                builder.append(GREEN);
            }

            builder.append(child.getName());
            builder.append(" ");
            builder.append(child.getSize());
            builder.append(RESET);

            if(!last) {
                builder.append("\n");
            }
        }

        return builder.toString();
    }
}

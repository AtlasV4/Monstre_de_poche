package com.esiea.pootd2.models;

import java.util.ArrayList;

public class FolderInode extends Inode {

    private ArrayList<Inode> children;
    private int size;

    public FolderInode(String name) {
        super(name);
        this.size = 0;
        this.children = new ArrayList<Inode>();
    }

    public void addInode(Inode inode) {
        inode.setParent(this);
        children.add(inode);
    }


    @Override
    public int getSize() {

        for(int i = 0; i < children.size(); i++) {
            this.size += children.get(i).getSize();
        }

        return this.size;
    }

    public ArrayList<Inode> getChildren() {
        return this.children;
    }
}

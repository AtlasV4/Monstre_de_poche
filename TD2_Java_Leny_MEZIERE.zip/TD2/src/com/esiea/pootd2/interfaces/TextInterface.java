package com.esiea.pootd2.interfaces;

import com.esiea.pootd2.controllers.ExplorerController;
import com.esiea.pootd2.controllers.IExplorerController;
import com.esiea.pootd2.models.FolderInode;

import java.util.Scanner;

public class TextInterface implements IUserInterface {

    private IExplorerController controller;

    public TextInterface(IExplorerController controller) {

        this.controller = controller;
    }

    @Override
    public void run() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print(getFullPath(controller.getCurrentFolder()) + "> ");
            String value = scanner.nextLine();

            if ("exit".equals(value)) {
                break;
            }

            String result = controller.executeCommand(value);
            if (result != null && !result.isEmpty()) {
                System.out.println(result);
            }
        }
    }

    private String getFullPath(FolderInode folder) {
        if (folder.getParent() == null) {
            return "/";
        }

        StringBuilder path = new StringBuilder();
        FolderInode current = folder;
        while (current != null && current.getParent() != null) {
            path.insert(0, "/" + current.getName());
            current = current.getParent();
        }

        return path.toString();
    }

}

package com.esiea.pootd2.commands.parsers;

import com.esiea.pootd2.commands.*;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;

public class UnixLikeCommandParser implements ICommandParser {
    @Override
    public Command parse(String command) {

        ParsedCommand cmd =  splitArguments(command);

        return mapCommand(cmd);

    }

    private ParsedCommand splitArguments(String command) {

        String[] cmd = command.trim().split(" ");

        String name = cmd[0];
        ArrayList<String> args = new ArrayList<>();

        for (int i = 1; i < cmd.length; i++) {
            args.add(cmd[i]);
        }

        return new ParsedCommand(name, args);
    }

    private Command mapCommand(ParsedCommand parsed) {

        switch (parsed.getName()) {

            case "ls":
                if (!parsed.getArgs().isEmpty()) {
                    return new ErrorCommand("Too many arguments for ls");
                }
                return new ListCommand();
            case "cd":
                if (parsed.getArgs().isEmpty()) {
                    return new ErrorCommand("Missing argument for cd");
                }
                if (parsed.getArgs().size() > 1) {
                    return new ErrorCommand("Too many arguments for cd");
                }
                return new ChangeDirectoryCommand(parsed.getArgs().getFirst());
            case "mkdir":
                if (parsed.getArgs().isEmpty()) {
                    return new ErrorCommand("Missing argument for mdkir");
                }
                if (parsed.getArgs().size() > 1) {
                    return new ErrorCommand("Too many arguments for mdkir");
                }
                return new MakeDirectoyCommand(parsed.getArgs().getFirst());
            case "touch":
                if (parsed.getArgs().isEmpty()) {
                    return new ErrorCommand("Missing argument for touch");
                }
                if (parsed.getArgs().size() > 1) {
                    return new ErrorCommand("Too many arguments for touch");
                }
                return new TouchCommand(parsed.getArgs().getFirst());
            default:
                return new ErrorCommand("Unknown command: " + parsed.getName());
        }
    }
}

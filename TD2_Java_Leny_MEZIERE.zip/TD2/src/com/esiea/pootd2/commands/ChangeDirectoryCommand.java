package com.esiea.pootd2.commands;

import com.esiea.pootd2.models.FileInode;
import com.esiea.pootd2.models.FolderInode;
import com.esiea.pootd2.models.Inode;

import java.util.Objects;

public class ChangeDirectoryCommand extends Command {

    private String path;

    public ChangeDirectoryCommand(String path) {
        this.path = path;
    }

    public FolderInode doCommand(FolderInode currentFolder) {

        if(Objects.equals(path,"..")) {
            currentFolder = currentFolder.getParent() != null ? currentFolder = currentFolder.getParent() : null;
            return currentFolder;
        }

        if(path.startsWith("../")) {
            String folderName = path.substring(path.indexOf("../")+3);
            if(currentFolder.getParent() != null) {

                for(int i = 0; i < currentFolder.getParent().getChildren().size(); i++) {
                    if(currentFolder.getParent().getChildren().get(i).getName().equals(folderName)) {
                        Inode inodeFound = currentFolder.getParent().getChildren().get(i);

                        if(inodeFound instanceof FileInode) {
                            continue;
                        }

                        currentFolder = (FolderInode) currentFolder.getParent().getChildren().get(i);
                        return currentFolder;
                    }
                }
            }
        }

        if(Objects.equals(path,".")) {
            return currentFolder;
        }

        for(int i = 0; i < currentFolder.getChildren().size(); i++) {
            if(currentFolder.getChildren().get(i).getName().equals(this.path)) {
                Inode inodeFound = currentFolder.getChildren().get(i);

                if(inodeFound instanceof FileInode) {
                    continue;
                }

                currentFolder = (FolderInode) currentFolder.getChildren().get(i);
                return currentFolder;
            }
        }

        return null;
    }
}

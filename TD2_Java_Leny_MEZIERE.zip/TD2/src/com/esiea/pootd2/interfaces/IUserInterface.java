package com.esiea.pootd2.interfaces;

public interface IUserInterface {

    public void run();
}

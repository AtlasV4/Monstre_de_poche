package com.esiea.pootd2.commands.parsers;

import java.util.ArrayList;

public class ParsedCommand {
    private final String name;
    private final ArrayList<String> args;

    public ParsedCommand(String name, ArrayList<String> args) {
        this.name = name;
        this.args = args;
    }

    public String getName() {
        return name;
    }

    public ArrayList<String> getArgs() {
        return args;
    }
}
